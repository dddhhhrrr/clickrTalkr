#ifndef CONTROLLER_H
#define CONTROLLER_H

class Controller{
	private:
	
	public:
		Controller();
	
};

#endif
