#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include "model.h"
#include "view.h"
#include "controller.h"

using namespace std;

int main() {
	int n;
	View view;
	view.initialize();
	view.drawBackground();
	view.show();
    std::cin >> n;
}
