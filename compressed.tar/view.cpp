#include "view.h"

View::View()
{
	int width, height;
    VGfloat w2, h2, w;
    
}

int View::getWidth(){
	return width;
}

int View::getHeight(){
	return height;
}

void View::drawBackground(){

    Background(0,0,0);
    Stroke(255,255,255,1);
    Fill(255,0,0,1.0);
    Circle(width/2, height/2, 100);

}

void View::initialize(){
	init(&width, &height);
	Start(width, height);
}

void View::show(){
	End();
}

void View::drawActiveButton(int x, int y, int diameter){
	VGfloat radius = diameter/2;
	VGfloat reflectionHeight = 0.7 * diameter;
	VGfloat reflectionWidth = 0.85 * diameter;
	VGfloat reflectionGap = 0.025 * diameter;
	
	VGfloat stops[] = {
		0.0, 0.0, 0.5, 1.0, 1.0, //posicion, r,g, b ,a
		1.0, 0.054, 0.156, 0.317, 1.0
	};
	
		VGfloat reflection[] = {
		0.0, 1.0, 1.0, 1.0, 0.4, //posicion, r,g, b ,a
		1.0, 1.0, 1.0, 1.0, 0.0
	};
	
	FillRadialGradient(x, y, x, y, radius+1, stops, 2);
	StrokeWidth(0);
	//Stroke(255,255,255,1);
	Circle(x, y, diameter);
	//Fill(255,255,255,0.5);
	FillLinearGradient(x, y + radius + reflectionHeight - reflectionGap + 1, x, y + radius - reflectionHeight - reflectionGap - 1, reflection, 2);
	Ellipse(x, y + radius - reflectionHeight/2 - reflectionGap, reflectionWidth, reflectionHeight);
}
