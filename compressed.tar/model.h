#ifndef MODEL_H
#define MODEL_H

class Model{
	private:
	
	public:
		Model();
	
};

#endif
